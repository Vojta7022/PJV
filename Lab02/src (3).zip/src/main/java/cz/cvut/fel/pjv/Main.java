package cz.cvut.fel.pjv;

import cz.cvut.fel.pjv.impl.Lab02;

public class Main {
    public static void main(String[] args) {
        Lab02 lab02 = new Lab02();
        lab02.main(args);
    }
}
