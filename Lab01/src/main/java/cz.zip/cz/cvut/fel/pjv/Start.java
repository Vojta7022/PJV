package cz.cvut.fel.pjv;

import cz.cvut.fel.pjv.impl.Lab01Impl;

public class Start {

   public static void main(String[] args) {
      Lab01 lab = new Lab01Impl();
      lab.homework();
   }

}